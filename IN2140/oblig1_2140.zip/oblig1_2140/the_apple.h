#ifndef THE_APPLE_H
#define THE_APPLE_H

extern char* apple;

#endif