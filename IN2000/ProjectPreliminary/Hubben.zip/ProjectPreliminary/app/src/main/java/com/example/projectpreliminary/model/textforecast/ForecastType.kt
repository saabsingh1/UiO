package com.example.projectpreliminary.model.textforecast

data class ForecastType(val name: String?, val locations: MutableList<ForecastLocation>?)
