package com.example.projectpreliminary.model.textforecast

import java.util.*

data class ForecastTime(val from : String?, val to : String?, val forecastType : ForecastType?)
