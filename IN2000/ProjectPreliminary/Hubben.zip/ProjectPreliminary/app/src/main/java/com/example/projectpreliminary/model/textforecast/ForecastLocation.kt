package com.example.projectpreliminary.model.textforecast

data class ForecastLocation(val name: String?, val id: String?, val content: String?)
